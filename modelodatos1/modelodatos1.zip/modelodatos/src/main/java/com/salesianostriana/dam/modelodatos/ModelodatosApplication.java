package com.salesianostriana.dam.modelodatos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModelodatosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ModelodatosApplication.class, args);
	}

}
