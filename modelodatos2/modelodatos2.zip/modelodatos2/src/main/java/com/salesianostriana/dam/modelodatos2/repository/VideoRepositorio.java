package com.salesianostriana.dam.modelodatos2.repository;

import com.salesianostriana.dam.modelodatos2.model.Video;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VideoRepositorio extends JpaRepository<Video, Long> {
}
