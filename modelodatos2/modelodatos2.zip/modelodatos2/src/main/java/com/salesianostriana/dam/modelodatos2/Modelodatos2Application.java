package com.salesianostriana.dam.modelodatos2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Modelodatos2Application {

	public static void main(String[] args) {
		SpringApplication.run(Modelodatos2Application.class, args);
	}

}
