package com.salesianostriana.dam.modelodatos2.repository;

import com.salesianostriana.dam.modelodatos2.model.Profesor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfesorRepositorio extends JpaRepository<Profesor, Long> {
}
